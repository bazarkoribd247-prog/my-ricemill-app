document.addEventListener('DOMContentLoaded', () => {
    // --- ১. ডার্ক মোড লজিক ---
    const themeToggle = document.getElementById('themeToggle');
    if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark-mode');

    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    });

    // --- ২. খরচ যোগ করার লজিক ---
    const form = document.getElementById('expenseForm');
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const expense = {
            date: document.getElementById('date').value,
            category: document.getElementById('category').value,
            desc: document.getElementById('desc').value,
            amount: parseFloat(document.getElementById('amount').value),
            paymentMethod: document.getElementById('paymentMethod').value
        };

        let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
        expenses.push(expense);
        localStorage.setItem('expenses', JSON.stringify(expenses));
        
        form.reset();
        updateUI(); // টেবিল ও স্ট্যাটাস আপডেট
    });

    // --- ৩. টেবিল ও ড্যাশবোর্ড আপডেট লজিক ---
    function updateUI() {
        const expenses = JSON.parse(localStorage.getItem('expenses')) || [];
        const tbody = document.getElementById('expenseTableBody');
        tbody.innerHTML = '';

        let total = 0, today = 0, monthly = 0;
        const todayStr = new Date().toISOString().split('T')[0];
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        expenses.forEach((item, index) => {
            total += item.amount;
            
            // আজকের খরচ চেক
            if (item.date === todayStr) today += item.amount;
            
            // মাসিক খরচ চেক
            const itemDate = new Date(item.date);
            if (itemDate.getMonth() === currentMonth && itemDate.getFullYear() === currentYear) {
                monthly += item.amount;
            }

            tbody.innerHTML += `<tr>
                <td>${item.date}</td>
                <td>${item.category}</td>
                <td>${item.amount}</td>
                <td><button onclick="deleteExpense(${index})" style="color:red;">মুছুন</button></td>
            </tr>`;
        });

        // ড্যাশবোর্ডে ভ্যালু বসানো
        document.getElementById('totalExpense').innerText = total;
        document.getElementById('todayExpense').innerText = today;
        document.getElementById('monthlyExpense').innerText = monthly;
    }

    // --- ৪. ডিলিট লজিক (গ্লোবাল স্কোপে রাখা যাতে HTML থেকে কল করা যায়) ---
    window.deleteExpense = (index) => {
        let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
        expenses.splice(index, 1);
        localStorage.setItem('expenses', JSON.stringify(expenses));
        updateUI();
    };

    // শুরুর সময় টেবিল লোড করা
    updateUI();
});

// --- ৫. সার্চ বা ফিল্টার লজিক ---
function filterTable() {
    const filter = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.getElementById('expenseTableBody').getElementsByTagName('tr');
    
    for (let row of rows) {
        const category = row.cells[1].innerText.toLowerCase();
        const desc = row.cells[2] ? row.cells[2].innerText.toLowerCase() : "";
        row.style.display = (category.includes(filter) || desc.includes(filter)) ? "" : "none";
    }
}