// ১. মূল ডাটাবেস ফাংশন
function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function getData(key) {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

// ২. ইউনিভার্সাল স্টক আপডেট ফাংশন (এটিই সব সমস্যার সমাধান করবে)
function adjustStock(name, qty, operation) {
  let stocks = getData('stockList');
  let item = stocks.find(s => s.name === name);
  
  // কিউটিটি (qty) বা পরিমাণ নিশ্চিত করুন
  let q = parseFloat(qty);
  
  if (item) {
    if (operation === 'subtract') {
      item.qty -= q; // বিয়োগ করা
    } else {
      item.qty += q; // যোগ করা
    }
  } else if (operation === 'add') {
    // যদি আইটেমটি খুঁজে না পায় তবে নতুন যোগ হবে
    stocks.push({ name: name, qty: q });
  }
  
  saveData('stockList', stocks);
}

// ৩. মিলিং এর সময় ব্যবহারের ফাংশন
function processMilling(paddyName, riceName, branName, paddyOut, riceIn, branIn) {
  adjustStock(paddyName, paddyOut, 'subtract'); // ধান কমল
  adjustStock(riceName, riceIn, 'add'); // চাল বাড়ল
  adjustStock(branName, branIn, 'add'); // কুঁড়া বাড়ল
}

// ৪. ব্যাকআপ সিস্টেম
function downloadBackup() {
  const data = JSON.stringify(localStorage);
  const blob = new Blob([data], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'rice_mill_backup.json';
  a.click();
}

console.log("সিস্টেম সফলভাবে লোড হয়েছে");
// ডাটা সেভ করার জন্য
function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

// ডাটা লোড করার জন্য
function getData(key) {
  let data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}
function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function getData(key) {
  let data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

// স্টক অ্যাডজাস্টমেন্ট ফাংশন
function adjustStock(name, qty, operation) {
  let stocks = getData('stockList');
  let item = stocks.find(s => s.name === name);
  let q = parseFloat(qty);
  if (item) {
    if (operation === 'subtract') item.qty -= q;
    else item.qty += q;
  } else if (operation === 'add') {
    stocks.push({ name: name, qty: q });
  }
  saveData('stockList', stocks);
}